window.addEventListener('load', function() {

  document.querySelector('.gz-ext').innerHTML = 'yes';

});

